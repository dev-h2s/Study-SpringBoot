package com.example.app.domain.type;

import lombok.Getter;

public enum FileType {
    REPRESENTATIVE, NON_REPRESENTATIVE;
}
